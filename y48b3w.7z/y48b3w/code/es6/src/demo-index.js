import App from './demo/App.js'

let app = new App('app')
app.init()